# Montra — WhatsApp + Telegram automation bridge

Montra links an authorized WhatsApp Web session to a Telegram control bot. It supports local chat/contact/message caching, trigger-based auto-replies, scheduled jobs, story tools, optional AI helpers and an optional authenticated local dashboard.

> **Important:** Baileys uses the WhatsApp Web protocol, which can change and may not expose all phone history, contacts, expired statuses or media. The application can only cache information that WhatsApp delivers to the linked session. Test all live WhatsApp features on an account you control. Use automation respectfully, obey WhatsApp terms, and repost only content you own or have permission to share.

## Telegram formatting, file transfer and history (v1.2.0)

- Telegram HTML formatting is sanitized centrally: only supported Telegram tags are preserved; placeholders such as `<n>` and `<HH:MM|+30m|date>` are escaped before every API call. Parse failures still retry without formatting.
- Telegram media downloads use Telegraf `getFileLink()` plus Node.js `fetch`, rather than Axios.
- Incoming WhatsApp media and media received from Telegram are written to `data/media/` before forwarding. The archive defaults to **500 MB total** and **200 MB per file**, evicting oldest archived files when space is needed. The archive index is `data/media-index.json`.
- `/historymedia <n>` retrieves media from selected chat history. `/media` lists locally archived files, `/media <n>` sends a stored file back to Telegram when the hosted Bot API size limit permits it, and `/mediastats` reports archive use. `/downloadstatus <n>` retrieves a cached status when available. It works only if the media payload remains downloadable from WhatsApp; expired or unavailable media cannot be reconstructed from text-only history.



The HTML sanitizer now catches punctuation-bearing placeholders too, including `<HH:MM|+30m|date>`, which caused the repeated `Unsupported start tag` errors.

- **403: the bot can't send messages to the bot** — the configured control/forwarding chat ID belongs to a bot account. Open your Montra bot from your personal Telegram account and send `/start`; use that human chat ID in `TELEGRAM_CHAT_ID` or `data/telegramConfig.json` `allowedChatIds`, then restart Montra. Bot-to-bot delivery is not supported by Telegram. Montra now pauses forwarding to a target after Telegram explicitly rejects it this way.
- **400: can't parse entities / unsupported start tag** — Montra retries the failed Telegram API call once without HTML parse mode so literal text containing angle brackets won't crash the handler.


## Media archive limits and platform constraints

- Defaults: `MEDIA_ARCHIVE_MAX_MB=500` total and `MEDIA_ARCHIVE_MAX_FILE_MB=200` per file. The oldest saved files are removed when the total limit would be exceeded. Files use restrictive local permissions and live in `data/media/`; treat this folder as private data.
- The hosted Telegram Bot API currently limits bot file downloads to about 20 MB and uploads to about 50 MB. Montra uses a conservative 45 MB upload threshold. Therefore, Telegram-origin files larger than the Bot API download limit cannot be fetched by a standard cloud bot, and WhatsApp files above the Telegram upload threshold can be archived locally but cannot be sent to Telegram through the hosted API. A self-hosted Telegram Local Bot API server is needed to change those Telegram-side limits.
- WhatsApp only delivers media that the linked session can access. Expired statuses and history records without downloadable media cannot be reconstructed; the archive queues all supported media included in live events and history sync, subject to availability and the configured storage limits.

## Requirements

- Node.js 18 or newer (Node 20+ recommended for built-in `fetch`, `FormData` and `Blob` support).
- A WhatsApp account you are authorized to link.
- A Telegram bot token from BotFather.
- Optional AI provider API key for AI functions.

## Install

```bash
npm install
cp .env.example .env
# edit .env, then:
npm test
npm start
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp`.

Set `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` and preferably `TELEGRAM_START_PIN`. `BOT_OWNER_NUMBER` / `PHONE_NUMBER` may be used by the existing pairing flow. Never share `.env`, `data/session`, or the sync cache. If credentials leak, revoke the linked device and rotate tokens.

## Core commands

### Chat, history and sync

- `/status` — connection status.
- `/ping` — Telegram/WhatsApp connection and forwarding health.
- `/whoami` — show your Telegram chat and user IDs for control-chat setup.
- `/mute <chat>` and `/unmute <chat>` — pause or restore forwarding for one WhatsApp chat; omit the target to use the active chat.
- `/chats` — cached chats.
- `/open <jid|phone|name>` and `/close` — select a chat.
- `/history [target] [count]` — show cached messages.
- `/historymedia <n>` — attempt to retrieve media from the selected history result when the original message still contains downloadable media.
- `/export [chat] [count]` — send a text file containing up to 100 cached messages; without a target, uses the active chat.
- `/search <text> [--from sender] [--after YYYY-MM-DD] [--before YYYY-MM-DD]` — search cached messages. Results show the decoded message text, or a `[kind]` label for media and system events, never the raw WhatsApp payload.
- `/findcontact <name or number>` searches synced contacts. `/contacts`, `/chatinfo <target>`, and `/groups` provide contact/chat/group information.
- `/groupinfo [group]` and `/groupmembers [group]` — inspect a group from the latest `/groups` list (by number, exact name, or JID); omit the target to use the active group.
- `/groupadmins [group]` — list group admins and owner.
- `/syncstatus` — cached chat/contact/message counts and cache limits.
- `/time [set <IANA>|shift <minutes>|reset]` — inspect or change the user clock used for wall-clock schedules and displays.
- `/forward on|off|all|active`, `/pause`, `/resume` — pause/resume incoming WhatsApp forwarding or choose whether all chats or only opened chats stream to Telegram.
- `/stream [on|off]` — live stream every new WhatsApp message with sender, time, `[chat|group|channel: name]`, a preview cut to two sentences, and buttons for Quick Reply, History, Details, React, AI Draft, Save to Files, Mute and Stop Stream. Quick Reply sends your next text (or media) as a quoted reply to that WhatsApp message; Stop Stream turns stream mode off in one tap.
- `/message [chat] <text>` (alias `/msg`) — send a WhatsApp message to the active chat, a resolved chat target, or the conversation quoted in the Telegram reply.
- `/alert <call|dm|mention|message|channel|any|keyword:<word>> <template>` — create Telegram alerts for incoming activity. Templates support `{name}`, `{text}`, `{action}`, `{time}`, `{date}`, `{day}`, `{phone}`, `{group}`, `{chat_type}`, `{message_id}`, `{kind}` and `{keyword}`. `/alert list`, `/alert on|off <id>`, `/alert del <id>` manage rules; `/calllog` shows recent incoming calls.
- `/status schedule <when> [caption]`, `/status queue`, `/status del <YYYY-MM-DD> <story_id>` — queue text, photo or video statuses. Manifests live in `stories/{date}/`; captions are stored for text statuses only. Reply to a photo/video with `/status schedule <when>` to queue that media.
- `/lock [pin]`, `/setpin <pin>`, `/start <PIN>` — lock both the dashboard and Telegram until `/start <PIN>` unlocks them. The PIN is stored as a salted scrypt hash; five wrong attempts pause unlocking for 60 seconds.
- `/jobs [pause|resume|del] <n>` — list and manage numbered scheduled jobs.
- `/privacy` — summarize local data counts, retention, media use, and forwarding settings.
- `/backup` — create a private snapshot of configuration, sync cache, scheduled jobs and audit log (session credentials excluded).

History commands search local data; they cannot force WhatsApp to provide arbitrary missing or expired history. Message content is stored in `data/syncStore.json` and may contain private information.

### File manager

A sandboxed store at `data/files/` you can push files to and pull back from through Telegram.

- `/files [path]` — list the store (folders first) with a ⬇️ button per file; the numbering from the last listing is what the other commands accept.
- `/fsput [name|path] [replace]` — attach a document, photo, video, animation, sticker, voice or audio message to the command and it is stored on the server. A name without a folder lands in the root; `replace` overwrites an existing entry.
- `/fsget <n|path>` — send a stored file back to Telegram.
- `/fsinfo <n|path>` — size, mtime, mode and (for small files) SHA-256.
- `/fsmkdir <path>`, `/fsmv <from> <to>`, `/fscp <from> <to>`, `/fsdel <n|path> [folder]` — organise and delete.
- `/fsfind <text>`, `/fstree [path] [depth]`, `/fsstats` — search, browse the whole tree, and see usage against the ceilings.

Everything is resolved inside the store root before it touches the disk: `..` segments are rejected, absolute paths must already be inside the root, each path segment is checked for symlinks and refuses to follow them, so the sync cache, media archive, configuration and session keys are unreachable from these commands. Writes are atomic (temp file plus rename) at mode `0600`, and folders are only deleted recursively when asked.

Ceilings, all overridable by environment variable: `FILE_STORE_MAX_FILE_MB` (50 MB per file), `FILE_STORE_MAX_TOTAL_MB` (500 MB quota), `FILE_STORE_MAX_ENTRIES` (2000). `MONTRA_FILE_STORE_DIR` relocates the store; `MONTRA_DATA_DIR` moves the whole data folder, which tests and preview runs rely on so they never touch a live installation.

Telegram's own limits still apply on top of the store: downloads from Telegram are capped at 20 MB per file, and sending a stored file back stops at the hosted Bot API's 45 MB upload ceiling — larger files stay on the server and `/fsget` answers with the absolute path instead. Uploading a file copies its contents to Telegram's servers, so only put material there you are willing to share with Telegram; every put, get, delete, move and copy is recorded in `data/tgAudit.jsonl`. Names coming from Telegram attachments are sanitised to a single segment; paths you type yourself are never allowed to escape the store.

### Interactive automation setup (wizard)

Every automation you would otherwise configure with a multi-argument command can be built one message at a time instead. The wizard asks a single question per message, shows the answer it will use if you take the default, and offers a disabled value where the field can legitimately be switched off.

- `/wizard` — pick a flow from the button menu (also on the control menu as 🧭 Guided setup)
- `/wizard <flow>` — start a flow directly: `autoreply`, `cron`, `remind`, `notify`, `forward`
- `/wizard status` — where the current setup is standing, with the answers so far
- `/wizard cancel` (or `/cancel`) — drop the session; nothing is written
- Bare `/autoreply add`, `/cron add`, `/remind`, `/notify`, `/forward setup` start the matching flow. The one-line forms still work: supplying the arguments skips the wizard entirely.

Each question accepts three kinds of input:

- **Typed answer** — validated exactly like the one-line command; a bad answer re-asks only that question.
- **Choice buttons** — where the field has a small fixed set of values (`dms` vs groups, `contains`/`exact`/`startsWith`/`regex`, common cooldowns, `+30m`/`+2h`, …). `⌨️ Type it` appears when a choice needs extra text, such as a WhatsApp contact for a job target.
- **♻️ Default** and **🚫 Disabled** — `Default:` shows the value used if you tap it, or `none — this one is required` when the field has none (a rule trigger, a message body). `Disabled:` shows what switching the field off means — no cooldown so every match replies, no active hours so the rule always runs, no schedule so a job is stored but never fires, a rule or job stored switched off. When a field cannot be disabled, that line says so.

Nothing touches disk until the confirm screen, which lists every answer and has a button per answer, so any question can be re-opened and changed out of order; changing an answer re-asks only the questions that follow it. `💾 Save` then applies the same validation and guards as the direct command (`{name}` placeholders, regex legality, target resolution, expiry parsing), and the action is written to `data/tgAudit.jsonl` with `source: "wizard"` (`wizard_start`, `wizard_cancel`, then `autoreply_rule_add` or `cron_add`). A session is per chat and expires 15 minutes after it started, so plain text is only claimed while a setup is open — with no wizard waiting, your messages keep going to WhatsApp as before. Commands always run first, so `/cancel`, `/menu` and every other verb work mid-wizard.

### Trigger-based auto-replies

Replies are disabled by default. Manage rules using `/autoreply`; supported rule fields include:

- `trigger`, `usage` (`dms` or `groups-mentioned`), `message`
- `match`: `contains`, `exact`, `startsWith`, or `regex`
- `priority` (higher runs first), `cooldownMin`, and `cooldownOff` (per-rule opt-out of any cooldown, so every matching message replies)
- optional `contacts` allow-list (JIDs or names)
- optional `schedule: { "start": "09:00", "end": "17:00" }` in the configured user timezone (see [Time and timezone](#time-and-timezone)). Telegram rule syntax can pass priority, a comma-separated contact allow-list, and `HH:MM-HH:MM` as fields 5–7

Placeholders include `{name}` and `{trigger}`. Invalid regular expressions are rejected. Group rules require a bot mention. Cooldowns and anti-ban send guards are applied. Rule hit counts are persisted as analytics.

### Jobs, reminders and AI cron

- `/remind +30m call John` — one-time Telegram reminder.
- `/remind 09:00 daily standup` — daily Telegram reminder.
- `/notify +2h check deployment` — one-time Telegram notification.
- `/cron` — list scheduled jobs.
- `/cron add <when> <target|me> <message>` — schedule a message.
- `/cron del <n>`, `/cron pause <n>`, `/cron resume <n>` — manage jobs.
- `/ai cron 18:00 Summarize today's priorities` — AI-generated scheduled Telegram update.
- `/ai story 09:00 <image prompt>` — generate and post an AI image as WhatsApp status daily (requires image API access and a connected WhatsApp session).

`<when>` accepts `HH:MM` (daily), `+30m`, `+2h`, `+1d` (one-time), or an ISO date/time such as `2026-12-31T15:00`. Wall-clock values use the configured user timezone. The scheduler checks every 30 seconds. Failed jobs retry with bounded delays and stop after three attempts. Keep the process running for scheduled jobs to fire.

### Time and timezone

Schedules are stored as absolute timestamps, so a post fires at the same instant no matter where the server runs or how its clock is set. Wall-clock input — `18:30`, `2026-12-31T15:00`, OTM `scheduleAt: "09:00"`, auto-reply active hours, and the daily buckets in `/analyze` — is interpreted on the user clock.

- `/time` — show the active timezone, clock correction, user clock and server clock.
- `/time set Africa/Nairobi` — IANA zone used for wall-clock parsing and displays; `server` follows the host zone.
- `/time shift +90` (or `-1h`) — manual correction when the host clock itself is wrong. The user clock is server time + shift.
- `/time reset` — remove the overrides and fall back to the environment.

Defaults live in `.env` (`MONTRA_TIMEZONE`, `MONTRA_TIME_SHIFT_MINUTES`). Runtime changes from `/time` are written to `data/timeConfig.json` (mode `0600`) and take precedence until reset. The dashboard date picker sends an absolute ISO instant from the browser, so it is already unambiguous. Existing scheduled entries keep the timestamp they were created with; changing the timezone only affects new wall-clock input and how times are displayed.

### AI tools (optional)

Gemini 2.5 Flash is the default provider for chat, summaries, translation, transcription and images. Set one default key in `MONTRA_DEFAULT_GEMINI_API_KEY` (or `GEMINI_API_KEY` / `GOOGLE_API_KEY`) and leave `MONTRA_AI_API_KEY` empty. A non-Gemini `MONTRA_AI_API_KEY` (for example an OpenAI-compatible endpoint) is used only when explicitly configured. No API key is bundled with the source: embedding a shared secret in a repository would let anyone spend it, and keys must be revocable per installation.

- `/ai status` — show the active provider, default-key source and model cascade.
- `/ai summarize [chat|all]` — summarize available cached messages.
- `/ai reply <message context>` — draft a reply; it is not sent automatically.
- `/ai cron <when> <prompt>` — scheduled AI-generated update.
- `/ai transcribe` while replying to a Telegram voice/audio attachment — transcribe that audio.
- `/ai story <HH:MM> <prompt>` — scheduled AI image story.

AI requests can transmit the supplied message text/audio to the configured provider. Configure this only if that data sharing is acceptable. AI-generated text and images can be wrong; review content before using it. AI image generation requires a provider endpoint and account with image-generation access. Transcription requires audio transcription access.

### Stories

- `/stories` — list status updates observed by the running session.
- `/statusview on|off` — optionally mark newly received WhatsApp statuses as viewed after a randomized 3–8 minute delay, with at least three minutes between view attempts. Off by default; disabling clears queued views.
- `/downloadstatus <n>` — attempt to retrieve cached status media.
- `/repoststatus <n>` — repost a status when media is still available and you have permission.
- `/poststatus <text>` or reply to an image/video with `/poststatus` — publish your own status.

WhatsApp does not guarantee that every contact's story or expired story media is available to the linked session. Scheduled AI stories post generated media to the account's status audience; verify the audience and privacy settings on the linked account first.

### Optional dashboard

The dashboard is disabled unless `DASHBOARD_TOKEN` is set. Configure:

```dotenv
DASHBOARD_TOKEN=use-a-long-random-secret
DASHBOARD_HOST=127.0.0.1
DASHBOARD_PORT=8787
```

Then restart Montra and open `http://127.0.0.1:8787/?token=YOUR_TOKEN`. API endpoints use the same token as a query parameter or `Authorization: Bearer ...` header. Avoid exposing the dashboard directly to the internet; use localhost or a properly secured reverse proxy.

#### Dashboard layout and views

The dashboard follows the WhatsApp Web layout and adapts to the screen: on desktop it uses the nav rail + chat list + conversation grid, and below 700px it collapses to a single column with a bottom navigation bar, a new-chat floating action button, full-width conversation slide-in and a bottom-sheet reaction bar. Icons are inline SVG so they inherit colour and scale; entry animations (chat rows, message bubbles, menus, sheets, toasts) only play for genuinely new items, so the 4-second refresh poll does not flicker, and everything is disabled under `prefers-reduced-motion`. Dark and light themes follow the WhatsApp Web palettes.

Views: **Chats** (search, All/Unread/Chats/Groups/Channels filters, archived section, new chat from a contact or phone number), **Status** (recent updates with a photo/video viewer plus a Scheduled posts queue that writes manifests to `stories/{date}/`), **Starred messages** and **Settings** (profile name/about/picture, theme, auto-reply rules, contact directory, alert rules and recent calls, local stats, encrypted backups, security lock, recent audit activity). Received status media is archived locally; if the first download missed it, opening the status retries through WhatsApp. When the security lock is active, every view is replaced by a PIN lock screen and API calls return HTTP 423 until it is unlocked.

#### Names and profile pictures come from the backend

The UI never renders a raw JID. `GET /api/chats`, `/api/contacts`, `/api/contact`, `/api/messages` and `/api/statuses` return a resolved `name` plus `type` (`chat`/`group`/`channel`/`broadcast`), `isGroup`, `isChannel`, `canSend` and `hasPicture`:

- Names come from the local contact cache first, then from WhatsApp metadata (group `subject`, newsletter `name`, contact `name`/`notify`/`verifiedName`) via a batched, TTL-cooled resolver (3 chats per pass, staggered, 6 h per hit / 10 min per miss) that persists results into the sync cache. Lookups are prioritised by the most recent message, so the chats you see first resolve first. Unknown names fall back to `Group`, `Channel`, `Broadcast list`, a formatted phone number or `WhatsApp user`.
- The dashboard deliberately does not resolve names for contacts you have never messaged, so opening the directory does not generate background WhatsApp traffic.
- Profile pictures are fetched server-side and proxied through `/api/avatar?jid=` (12 h positive / 1 h negative cache, 400 entries, 5 MB cap). `hasPicture` is `true`, `false`, or `null` when the chat has never been probed, so the UI only requests pictures that plausibly exist and remembers a "no picture" answer instead of re-requesting it on every refresh.

#### Channels and broadcast lists are read-only

Channels (`@newsletter`) and broadcast lists sync posts and reactions but cannot receive messages. The composer is replaced by an explanatory strip, Reply/Delete are removed from message actions, presence subscription is skipped, and the backend rejects `POST /api/messages`, `/api/media/send` and `/api/media/upload` to those JIDs. The same rule is enforced one level lower, in the outbound choke point every sender shares (Telegram `/send`, `/sendmedia`, plain replies to an active chat and cron/AI jobs), so a channel or broadcast JID typed by hand is refused with "Channels and broadcast lists are receive-only." instead of reaching WhatsApp. Status posting is unaffected: it uses its own `status@broadcast` path. Channel posts surface in the Channels tab, the `status@broadcast` pseudo-chat stays out of the chat list because Status has its own view, and `/analyze` ignores newsletter traffic.

#### Chat features

- Chat list with pin, mute, archive and mark-unread state, unread badges, per-chat last-message preview and delivery ticks.
- Conversation header with contact/group info drawer (about, group description, participants, shared media grid), in-chat search with match navigation and highlighting, mute/archive, and history export.
- Send text, quoted replies, emoji picker, reactions, and revoke of your own messages; message actions are available on hover (desktop) or long press (touch), plus the classic right-click menu.
- Media: upload images/video/audio/documents up to 15 MB, send archived media, view image/video/audio/document bubbles in a full-screen viewer, and play or download archived attachments.
- Live state: connection strip, contact presence and typing indicators, read receipts applied when a conversation is opened, and automatic refresh of incoming messages and status ticks.
- Status: shows the status updates delivered to the linked session, marks a status viewed when opened, and posts text or image/MP4 statuses to the audience available to Montra.
- Profile settings can update the linked account's name, about text and profile picture.

Dashboard messages pass through Montra's anti-abuse checks and audit logging. The dashboard requires authentication and binds to localhost by default.

> **Local preferences:** pin, mute, archive, mark-unread, starred messages and theme are stored per-dashboard in `data/dashboardPrefs.json`. They are not synced to or from the WhatsApp app, and they are separate from WhatsApp's own pinned/archived/muted state. Reactions, replies and revokes are sent as real WhatsApp actions; profile pictures are proxied through `/api/avatar` because the WhatsApp CDN URLs are not directly loadable by the browser. The logo, favicon and the default avatars (`assets/montra.svg`, `chat.svg`, `group.svg`, `channel.svg`) are served from `/assets/<name>.svg`. That route is the only unauthenticated dashboard route: it accepts one flat filename matched against `[a-z0-9][a-z0-9-]{0,40}\.svg`, so browsers can load them before the token exists and directory traversal is impossible.


### One-time message API (OTM)

`/api/otm` sends one WhatsApp message per request. It authenticates with `MONTRA_OTM_KEY` and never asks for `DASHBOARD_TOKEN`, so the key you put in a link or integration cannot unlock the dashboard. The endpoint lives on the same server as the dashboard, is blocked while `/lock` is active (HTTP 423), and still passes every send through the anti-ban cooldown, typing simulation and audit log.

```bash
# Instant send with a link (GET)
curl "http://127.0.0.1:8787/api/otm?key=$MONTRA_OTM_KEY&to=254712345678&message=Hello%20%7Bname%7D"

# Scheduled send with JSON (POST)
curl -X POST http://127.0.0.1:8787/api/otm \
  -H "Content-Type: application/json" \
  -H "X-OTM-Key: $MONTRA_OTM_KEY" \
  -d '{"to":"254712345678","message":"Hi {name}, your code is {code}.","vars":{"code":"A1B2"},"scheduleAt":"+30m","idempotencyKey":"order-42"}'
```

- **Message limit:** 600 Unicode characters, checked before and after variable substitution.
- **Variables:** `{name}` (contact or group name), `{phone}`, `{jid}`, `{time}`, `{date}`, `{day}`, `{timestamp}`, `{iso}`, plus any keys you pass in `vars`. Unknown placeholders stay untouched.
- **Recipients:** a phone number (7–15 digits with country code) or a `@s.whatsapp.net` / `@g.us` JID. Channels and broadcast lists are rejected because they are receive-only.
- **Instant vs scheduled:** omit `scheduleAt` (or use `now`) to send immediately within the global cooldown. Accepts ISO timestamps, `HH:MM`, or `+30m` / `+2h` / `+1d`; `HH:MM` uses `MONTRA_TIMEZONE`. Scheduled jobs are stored in `data/otmJobs.json` (mode `0600`), retried up to 3 times on transient failures, and survive a restart; a job interrupted mid-send is failed rather than sent twice.
- **Idempotency:** `idempotencyKey` replays the original response for 24 hours instead of sending again.
- **Responses:** JSON with `ok`, `returnValue` (`0` success, `1` failure), `code`, `status`, `id`, and a human-readable `message`; failures also include `help`. Add `&format=text` for a plain-text reply.
- **Help:** `GET /api/otm/help` (or calling `/api/otm` without a key or with bad syntax) returns usage help. `GET /api/otm/status` with a valid key reports configuration and pending jobs.
- **Security:** prefer the `X-OTM-Key` header over the `?key=` query string, bind the dashboard to localhost, and put the endpoint behind HTTPS/VPN before exposing it beyond the local machine. Rotate `MONTRA_OTM_KEY` by updating `.env` and restarting.

### Cache retention and backups

- `SYNC_MAX_MESSAGES_PER_CHAT=500` controls messages retained per chat (minimum 50).
- `SYNC_RETENTION_DAYS=0` disables time-based pruning. Set a positive value to delete older cached messages; pruning runs hourly.
- `/backup` creates local snapshots in `data/backups/`; daily snapshots run at `BACKUP_HOUR` (default 03:00 server local time) and only the newest `BACKUP_KEEP_COUNT` (default 7) are retained. Snapshots include sync cache/config/dashboard preferences/audit files but exclude `data/session/` and the `data/media/` files themselves. Backups still contain private chat content: restrict filesystem access and encrypt off-device copies.
- Audit events are written to `data/tgAudit.jsonl`.
- `MONTRA_SYNC_STORE=/path/to/syncStore.json` relocates the chat/contact/message cache. Tests and UI previews use it to run against a throwaway cache instead of the live one; leave it unset for normal operation.
- `MONTRA_DATA_DIR=/path/to/dir` relocates every other on-disk store at once (media archive and its files, dashboard preferences, auto-reply config, analysis cache, backup snapshots and audit logs). `npm test` sets it to a temporary directory so a test run can never write into, lock or rename a file inside the real `data/` while a live session is using it. Leave it unset for normal operation.

## Security

- Only allow trusted Telegram control chat IDs; configure `TELEGRAM_START_PIN` before allowing new chats to register.
- `/lock` blocks both the dashboard and Telegram. The dashboard API returns HTTP 423 and the browser shows a PIN screen; Telegram rejects commands and forwards until `/start <PIN>` succeeds. Unlock attempts are rate-limited to five failures per 60 seconds, and the PIN is stored as a salted scrypt hash in `data/securityLock.json` (mode `0600`).
- Keep `DASHBOARD_TOKEN` strong and private.
- Never publish tokens, auth sessions, personal chat exports or sync cache files.
- The file manager only serves the Telegram chats already allowed by the bridge's auth gate, and only the `data/files/` folder — path containment and per-segment symlink refusal keep it out of the sync cache, media archive, config and session keys. Anyone with access to an allowed control chat can therefore read and upload files there; keep `TELEGRAM_START_PIN` set and control-chat IDs tight.
- Bulk sending and unsolicited messaging are intentionally not encouraged. Existing anti-ban/rate controls can block sends.
- Warmup ramps from the date Montra was first started, which is recorded in `data/antiBanConfig.json` on that first run and then kept across restarts. Daily caps go 25 → 50 → 100 → 200 → 500 messages as that date ages; deleting the file restarts the ramp at 25. Set `warmupMode: false` in that file to remove the daily cap entirely.
- Ensure group moderation and auto-replies comply with participant expectations and applicable law.

## Testing and verification

```bash
npm run selftest   # loads every lib module, exercises each one, checks the dashboard over HTTP, then runs npm test
npm test
node --check index.js
node --check lib/telegramEngine.js
node --check lib/automationWizard.js
node --check lib/autoReplyEngine.js
node --check lib/fileStoreEngine.js
node --check lib/syncStore.js
node --check lib/aiAssistant.js
node --check lib/dashboard.js
node --check lib/otmEngine.js
```

Tests cover message decoding and layer unwrapping, sync cache deduplication and ordering, status scheduler manifests plus the caption-only-for-text rule and path validation, timezone parsing (IANA zones, DST transitions, manual clock shift and config persistence), alert triggers (including keywords and channel posts) and template variables, security PIN hashing/lockout behaviour, Gemini default-key precedence versus custom providers, and the OTM API (key separation from the dashboard token, help/error responses, variable substitution, the 600-character cap, scheduling, idempotency, file permissions and the security-lock gate). Each run points `MONTRA_DATA_DIR` and `MONTRA_SYNC_STORE` at a temporary directory, so it never touches a live installation. The tests do not log in to WhatsApp or Telegram and do not make external AI API calls.

`selftest.js` runs the same isolation rules: it sets a temporary data directory, syntax-checks every project file, resolves every dependency, loads every `lib/*.js` module, exercises the media archive, scheduler, security, OTM, alerts, analytics, anti-ban, CRM, file store, backups, markdown, formatting, AI provider status, automation wizard, Telegram status cache and dashboard HTTP routes, validates the dashboard's inline script, and finishes by running the `node --test` suite. It exits non-zero if any group fails and prints a pass/fail summary.

## Known limitations / live verification required

1. WhatsApp full-history sync is controlled by WhatsApp/Baileys and may be partial.
2. Contact names and chat metadata update only when sync events are delivered.
3. Media retrieval depends on original message keys and media still being accessible; expired status media may be unavailable.
4. AI provider key, model access, image generation, and audio transcription must be verified with your provider.
5. The dashboard does not implement WhatsApp voice/video calls, linked-device management, group administration, message editing, or communities. Channels are read-only: Montra shows already-synced posts, reactions and channel metadata but cannot follow, unmute, or reply to them. Reactions, replies and revoke are sent as real WhatsApp protocol actions, but revoke only applies to your own messages and WhatsApp still has to accept it. Polls, broadcasts and view-once messages are not rendered as interactive cards — they appear as text or an unsupported-attachment placeholder. Status visibility and audience are limited to what the linked WhatsApp session and Baileys expose.
6. Cron jobs run only while Montra is running; use a process manager for availability and backups.
7. Scheduled AI status posting and all outbound WhatsApp sends require live testing, valid account access and review of status privacy settings.

